$(function () {
// jQuery Code goes here
$('.toggleBtn').click( function(){
$(this).toggleClass("toggleOn");
} );
})